import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import '../theme/app_theme.dart';
import 'dashboard_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool inscription = true;
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _passCtrl = TextEditingController();

  void _valider() {
    // TODO: remplacer par un vrai appel API (création de compte / connexion).
    final nom = _nameCtrl.text.trim().isEmpty ? 'Candidat' : _nameCtrl.text.trim();
    context.read<AppState>().connecter(nom);
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const DashboardScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // --- Marque ---
              Column(
                children: [
                  Container(
                    width: 58,
                    height: 58,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                        colors: [AppColors.greenMid, AppColors.greenDeep],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      border: Border.all(color: AppColors.gold, width: 2),
                    ),
                    alignment: Alignment.center,
                    child: Text('V',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            color: AppColors.goldSoft, fontSize: 22)),
                  ),
                  const SizedBox(height: 10),
                  Text('VONONA', style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 2),
                  Text('CONCOURS POLICE · MADAGASIKARA',
                      style: TextStyle(
                          fontSize: 10,
                          letterSpacing: 1.6,
                          color: AppColors.slate,
                          fontWeight: FontWeight.w600)),
                ],
              ),
              const SizedBox(height: 24),

              // --- Onglets Connexion / Inscription ---
              Container(
                padding: const EdgeInsets.all(3),
                decoration: BoxDecoration(
                  color: const Color(0xFFE6DFCC),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  children: [
                    _tab('Connexion', !inscription),
                    _tab('Créer un compte', inscription),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              if (inscription) ...[
                _field('Nom complet', _nameCtrl, hint: 'Rakoto Andriamampianina'),
                const SizedBox(height: 14),
              ],
              _field('Numéro de téléphone', _phoneCtrl, hint: '034 XX XXX XX'),
              const SizedBox(height: 14),
              _field('Mot de passe', _passCtrl, hint: '••••••••', obscure: true),

              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _valider,
                child: Text(inscription ? 'Créer mon compte' : 'Se connecter'),
              ),
              const SizedBox(height: 12),
              OutlinedButton(
                onPressed: () => setState(() => inscription = !inscription),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.greenDeep,
                  side: const BorderSide(color: AppColors.greenDeep, width: 1.4),
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                child: Text(inscription ? "J'ai déjà un compte" : "Créer un compte"),
              ),
              const SizedBox(height: 18),
              Text(
                "En continuant, vous acceptez les Conditions d'utilisation et la Politique de confidentialité.",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 11, color: AppColors.slate, height: 1.5),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _tab(String label, bool active) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 9),
        decoration: BoxDecoration(
          color: active ? AppColors.greenDeep : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
        ),
        alignment: Alignment.center,
        child: Text(
          label,
          style: TextStyle(
            color: active ? AppColors.ivory : AppColors.slate,
            fontWeight: FontWeight.w600,
            fontSize: 13,
          ),
        ),
      ),
    );
  }

  Widget _field(String label, TextEditingController ctrl,
      {String? hint, bool obscure = false}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: TextStyle(
                fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.slate)),
        const SizedBox(height: 6),
        TextField(
          controller: ctrl,
          obscureText: obscure,
          decoration: InputDecoration(hintText: hint),
        ),
      ],
    );
  }
}
