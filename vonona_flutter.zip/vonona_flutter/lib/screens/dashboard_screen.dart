import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/rank_chevrons.dart';
import 'courses_screen.dart';
import 'subscription_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // --- En-tête vert avec niveau + galons ---
              Container(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [AppColors.greenMid, AppColors.greenDeep],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(22),
                    bottomRight: Radius.circular(22),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        RichText(
                          text: TextSpan(
                            style: const TextStyle(
                                fontSize: 13, color: Color(0xB3F4EFE4)),
                            children: [
                              const TextSpan(text: 'Bonjour, '),
                              TextSpan(
                                text: state.userName ?? 'Candidat',
                                style: const TextStyle(
                                    color: AppColors.ivory,
                                    fontWeight: FontWeight.w700),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding:
                              const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: AppColors.gold.withOpacity(0.22),
                            border: Border.all(color: AppColors.gold),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            'NIVEAU ${state.niveauActuel.label}',
                            style: const TextStyle(
                                color: AppColors.goldSoft,
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                                letterSpacing: 1),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    const RankChevrons(filled: 2),
                    const SizedBox(height: 8),
                    const Text(
                      "Progression globale — 42% avant l'examen",
                      style: TextStyle(fontSize: 10.5, color: Color(0xA6F4EFE4)),
                    ),
                  ],
                ),
              ),

              _sectionTitle('Matières du jour'),
              _subjectCard(
                context,
                title: 'Culture générale',
                tag: 'Gratuit',
                free: true,
                progress: 0.70,
              ),
              _subjectCard(
                context,
                title: 'Droit & procédure pénale',
                tag: '🔒 Premium',
                free: false,
                progress: 0.15,
              ),
              _subjectCard(
                context,
                title: 'Condition physique',
                tag: '🔒 Premium',
                free: false,
                progress: 0.05,
              ),

              _sectionTitle('Cette semaine'),
              _subjectCard(
                context,
                title: 'Quiz blanc chronométré',
                tag: '3 essais',
                free: true,
                progress: 0.30,
              ),

              // --- Bannière d'abonnement ---
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 6, 20, 24),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [AppColors.greenDeep, AppColors.greenMid],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text('Débloquez les 4 niveaux',
                          style: TextStyle(
                              color: AppColors.ivory,
                              fontWeight: FontWeight.w700,
                              fontSize: 15)),
                      const SizedBox(height: 4),
                      const Text(
                        'Accès illimité à tous les cours, quiz et corrections détaillées.',
                        style: TextStyle(color: Color(0xBFF4EFE4), fontSize: 11.5),
                      ),
                      const SizedBox(height: 12),
                      ElevatedButton(
                        onPressed: () => Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => const SubscriptionScreen()),
                        ),
                        child: const Text('Voir les abonnements'),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Accueil'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), label: 'Cours'),
          NavigationDestination(icon: Icon(Icons.workspace_premium_outlined), label: 'Abonnement'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profil'),
        ],
        onDestinationSelected: (i) {
          if (i == 1) {
            Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const CoursesScreen()),
            );
          } else if (i == 2) {
            Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const SubscriptionScreen()),
            );
          }
        },
      ),
    );
  }

  Widget _sectionTitle(String text) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 10),
        child: Text(text.toUpperCase(),
            style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: AppColors.greenDeep,
                letterSpacing: 0.5)),
      );

  Widget _subjectCard(
    BuildContext context, {
    required String title,
    required String tag,
    required bool free,
    required double progress,
  }) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: AppColors.cardLine),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(title,
                    style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600)),
                Text(tag,
                    style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        color: free ? AppColors.freeGreen : AppColors.slate)),
              ],
            ),
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: progress,
                minHeight: 6,
                backgroundColor: const Color(0xFFEFE9DA),
                color: free ? AppColors.greenMid : AppColors.gold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
