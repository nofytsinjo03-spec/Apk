import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import '../theme/app_theme.dart';
import 'subscription_screen.dart';

/// Représente un chapitre d'un module. [free] = accessible sans abonnement.
class _Chapitre {
  final String titre;
  final String sousTitre;
  final bool free;
  const _Chapitre(this.titre, this.sousTitre, this.free);
}

const _chapitres = [
  _Chapitre('Ch. 1 — Introduction au droit pénal', '12 min · Fiche + Quiz', true),
  _Chapitre('Ch. 2 — La garde à vue', '18 min · Fiche + Quiz', true),
  _Chapitre('Ch. 3 — Le flagrant délit', '15 min · Fiche + Quiz', false),
  _Chapitre('Ch. 4 — Instruction judiciaire', '20 min · Fiche + Quiz', false),
  _Chapitre('Ch. 5 — Examen blanc complet', '45 min · 40 questions', false),
];

class CoursesScreen extends StatelessWidget {
  const CoursesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final abonne = context.watch<AppState>().abonnementActif;
    final niveau = context.watch<AppState>().niveauActuel.label;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.ivory,
        elevation: 0,
        foregroundColor: AppColors.ink,
        title: Text('Droit & procédure pénale · $niveau'),
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 10),
        children: [
          for (final chap in _chapitres)
            _chapitreTile(context, chap, deverrouille: chap.free || abonne),

          // --- Bannière incitant à l'abonnement, cachée si déjà abonné ---
          if (!abonne)
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [AppColors.greenDeep, AppColors.greenMid],
                  ),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text('Il vous reste 3 chapitres',
                        style: TextStyle(
                            color: AppColors.ivory,
                            fontWeight: FontWeight.w700,
                            fontSize: 15)),
                    const SizedBox(height: 4),
                    const Text(
                      "Abonnez-vous pour continuer ce module et débloquer les 3 autres niveaux.",
                      style: TextStyle(color: Color(0xBFF4EFE4), fontSize: 11.5),
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton(
                      onPressed: () => Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const SubscriptionScreen()),
                      ),
                      child: const Text("S'abonner maintenant"),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _chapitreTile(BuildContext context, _Chapitre chap, {required bool deverrouille}) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
      child: Material(
        color: deverrouille ? Colors.white : const Color(0xFFF0ECE0),
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () {
            if (!deverrouille) {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const SubscriptionScreen()),
              );
            }
            // Si déverrouillé : naviguer vers l'écran de contenu/quiz (à implémenter).
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
            decoration: BoxDecoration(
              border: Border.all(color: AppColors.cardLine),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(chap.titre,
                          style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 3),
                      Text(chap.sousTitre,
                          style: const TextStyle(fontSize: 10.5, color: AppColors.slate)),
                    ],
                  ),
                ),
                if (deverrouille && chap.free)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: AppColors.freeGreen,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Text('Gratuit',
                        style: TextStyle(
                            color: Colors.white, fontSize: 9.5, fontWeight: FontWeight.w600)),
                  )
                else if (!deverrouille)
                  const Icon(Icons.lock, size: 18, color: AppColors.gold)
                else
                  const Icon(Icons.check_circle, size: 18, color: AppColors.freeGreen),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
