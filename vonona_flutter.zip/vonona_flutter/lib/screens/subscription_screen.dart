import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import '../theme/app_theme.dart';

enum MobileMoneyProvider { mvola, orangeMoney, airtelMoney }

extension MMLabel on MobileMoneyProvider {
  String get label {
    switch (this) {
      case MobileMoneyProvider.mvola:
        return "M'VOLA";
      case MobileMoneyProvider.orangeMoney:
        return 'ORANGE\nMONEY';
      case MobileMoneyProvider.airtelMoney:
        return 'AIRTEL\nMONEY';
    }
  }

  Color get dotColor {
    switch (this) {
      case MobileMoneyProvider.mvola:
        return const Color(0xFFFFC700);
      case MobileMoneyProvider.orangeMoney:
        return const Color(0xFFFF7900);
      case MobileMoneyProvider.airtelMoney:
        return const Color(0xFFE4022D);
    }
  }
}

class _Plan {
  final String nom;
  final int prixAr;
  final String desc;
  final bool recommande;
  const _Plan(this.nom, this.prixAr, this.desc, {this.recommande = false});
}

const _plans = [
  _Plan('1 mois', 9900, 'Accès à 1 niveau au choix'),
  _Plan('3 mois', 22500, 'Tous les niveaux EAP à ECP + examens blancs',
      recommande: true),
  _Plan('12 mois', 69000, 'Accès complet + certificat de suivi'),
];

class SubscriptionScreen extends StatefulWidget {
  const SubscriptionScreen({super.key});

  @override
  State<SubscriptionScreen> createState() => _SubscriptionScreenState();
}

class _SubscriptionScreenState extends State<SubscriptionScreen> {
  int planIndex = 1; // "3 mois" présélectionné, comme dans la maquette
  MobileMoneyProvider provider = MobileMoneyProvider.mvola;
  final _phoneCtrl = TextEditingController();
  bool enCours = false;

  Future<void> _payer() async {
    // TODO: remplacer par l'appel réel au gateway du provider choisi
    // (API marchand M'vola / Orange Money / Airtel Money), avec vérification
    // du statut de la transaction côté backend avant d'activer l'abonnement.
    setState(() => enCours = true);
    await Future.delayed(const Duration(seconds: 2));
    if (!mounted) return;
    context.read<AppState>().activerAbonnement();
    setState(() => enCours = false);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Paiement confirmé. Abonnement activé ✅')),
    );
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final plan = _plans[planIndex];

    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.ivory,
        elevation: 0,
        foregroundColor: AppColors.ink,
        title: const Text('Abonnement'),
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 14),
        children: [
          _sectionTitle('Choisissez votre formule'),
          for (int i = 0; i < _plans.length; i++)
            _planCard(_plans[i], selected: i == planIndex, onTap: () {
              setState(() => planIndex = i);
            }),

          _sectionTitle('Mode de paiement', top: 22),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: MobileMoneyProvider.values.map((p) {
                final sel = p == provider;
                return Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: () => setState(() => provider = p),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: sel ? const Color(0xFFF4F1E8) : Colors.white,
                          border: Border.all(
                              color: sel ? AppColors.greenDeep : AppColors.cardLine,
                              width: sel ? 1.6 : 1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Column(
                          children: [
                            Container(
                              width: 26,
                              height: 26,
                              decoration:
                                  BoxDecoration(shape: BoxShape.circle, color: p.dotColor),
                            ),
                            const SizedBox(height: 6),
                            Text(p.label,
                                textAlign: TextAlign.center,
                                style: const TextStyle(fontSize: 9.5, fontWeight: FontWeight.w700)),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),

          Padding(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Numéro Mobile Money',
                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.slate)),
                const SizedBox(height: 6),
                TextField(
                  controller: _phoneCtrl,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(hintText: '034 XX XXX XX'),
                ),
              ],
            ),
          ),

          Padding(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 8),
            child: ElevatedButton(
              onPressed: enCours ? null : _payer,
              child: enCours
                  ? const SizedBox(
                      height: 18, width: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : Text('Payer ${plan.prixAr} Ar'),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Text(
              "Vous recevrez une demande de confirmation ${provider.label.replaceAll('\n', ' ')} sur votre téléphone pour valider le paiement.",
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 11, color: AppColors.slate, height: 1.5),
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _sectionTitle(String text, {double top = 4}) => Padding(
        padding: EdgeInsets.fromLTRB(20, top, 20, 10),
        child: Text(text,
            style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: AppColors.slate)),
      );

  Widget _planCard(_Plan plan, {required bool selected, required VoidCallback onTap}) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(
                  color: selected ? AppColors.gold : AppColors.cardLine,
                  width: selected ? 1.6 : 1,
                ),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(plan.nom, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                      RichText(
                        text: TextSpan(
                          style: const TextStyle(
                              color: AppColors.redFlag, fontWeight: FontWeight.w600, fontSize: 17),
                          children: [
                            TextSpan(text: '${plan.prixAr} '),
                            const TextSpan(
                                text: 'Ar',
                                style: TextStyle(
                                    fontSize: 10, color: AppColors.slate, fontWeight: FontWeight.normal)),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 5),
                  Text(plan.desc, style: const TextStyle(fontSize: 11, color: AppColors.slate)),
                ],
              ),
            ),
            if (plan.recommande)
              Positioned(
                top: -9,
                left: 14,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(color: AppColors.gold, borderRadius: BorderRadius.circular(20)),
                  child: const Text('RECOMMANDÉ',
                      style: TextStyle(
                          fontSize: 8.5,
                          letterSpacing: 0.6,
                          fontWeight: FontWeight.w700,
                          color: AppColors.greenDeep)),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
