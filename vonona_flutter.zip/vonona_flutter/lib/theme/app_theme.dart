import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Palette et typographies de VONONA.
/// Reprend le vert institutionnel malgache, l'ivoire, l'or (grade/insigne)
/// et le rouge du drapeau comme accent d'action.
class AppColors {
  static const greenDeep = Color(0xFF122A22);
  static const greenMid = Color(0xFF1F4636);
  static const ivory = Color(0xFFF4EFE4);
  static const redFlag = Color(0xFFC8102E);
  static const gold = Color(0xFFB8923F);
  static const goldSoft = Color(0xFFD8BE85);
  static const ink = Color(0xFF17201C);
  static const slate = Color(0xFF6E7871);
  static const cardLine = Color(0xFFEAE3D0);
  static const freeGreen = Color(0xFF1F7A4C);
}

class AppTheme {
  static ThemeData get light {
    final base = ThemeData.light();
    return base.copyWith(
      scaffoldBackgroundColor: AppColors.ivory,
      colorScheme: base.colorScheme.copyWith(
        primary: AppColors.greenDeep,
        secondary: AppColors.gold,
        error: AppColors.redFlag,
      ),
      textTheme: GoogleFonts.sourceSans3TextTheme(base.textTheme).copyWith(
        // Titres en Oswald (condensé, autoritaire) — cohérent avec la maquette
        titleLarge: GoogleFonts.oswald(
          fontWeight: FontWeight.w700,
          fontSize: 22,
          letterSpacing: 0.5,
          color: AppColors.greenDeep,
        ),
        titleMedium: GoogleFonts.oswald(
          fontWeight: FontWeight.w600,
          fontSize: 15,
          color: AppColors.greenDeep,
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.redFlag,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          textStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(9),
          borderSide: const BorderSide(color: AppColors.cardLine),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(9),
          borderSide: const BorderSide(color: AppColors.cardLine),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(9),
          borderSide: const BorderSide(color: AppColors.greenDeep, width: 1.4),
        ),
      ),
    );
  }
}
