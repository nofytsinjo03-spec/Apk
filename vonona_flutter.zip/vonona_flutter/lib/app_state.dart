import 'package:flutter/foundation.dart';

/// Les 4 niveaux de concours de la Police malgache.
enum Niveau { eap, eip, eop, ecp }

extension NiveauLabel on Niveau {
  String get label {
    switch (this) {
      case Niveau.eap:
        return 'EAP';
      case Niveau.eip:
        return 'EIP';
      case Niveau.eop:
        return 'EOP';
      case Niveau.ecp:
        return 'ECP';
    }
  }
}

/// État partagé de l'application, injecté via Provider dans main.dart.
/// Dans une vraie appli, ces valeurs viendraient du backend après
/// connexion / paiement — ici elles vivent en mémoire pour la démo.
class AppState extends ChangeNotifier {
  String? userName;
  Niveau niveauActuel = Niveau.eop;
  bool abonnementActif = false;

  void connecter(String nom) {
    userName = nom;
    notifyListeners();
  }

  void choisirNiveau(Niveau niveau) {
    niveauActuel = niveau;
    notifyListeners();
  }

  void activerAbonnement() {
    abonnementActif = true;
    notifyListeners();
  }
}
