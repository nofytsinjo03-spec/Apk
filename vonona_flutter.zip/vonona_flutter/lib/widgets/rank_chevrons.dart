import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Petit galon en chevrons, inspiré des insignes de grade.
/// [filled] = nombre de chevrons "acquis" sur [total].
class RankChevrons extends StatelessWidget {
  final int filled;
  final int total;
  final double width;
  final double height;

  const RankChevrons({
    super.key,
    required this.filled,
    this.total = 4,
    this.width = 26,
    this.height = 7,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(total, (i) {
        final bool on = i < filled;
        return Padding(
          padding: const EdgeInsets.only(right: 4),
          child: ClipPath(
            clipper: _ChevronClipper(),
            child: Container(
              width: width,
              height: height,
              color: AppColors.gold.withOpacity(on ? 1 : 0.3),
            ),
          ),
        );
      }),
    );
  }
}

/// Découpe la forme "chevron" (parallélogramme incliné) utilisée
/// dans la maquette HTML via clip-path.
class _ChevronClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    path.moveTo(size.width * 0.15, 0);
    path.lineTo(size.width, 0);
    path.lineTo(size.width * 0.85, size.height);
    path.lineTo(0, size.height);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) => false;
}
